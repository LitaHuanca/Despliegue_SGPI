"""Inicialización del paquete core."""
